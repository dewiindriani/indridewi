-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 29, 2013 at 11:45 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `hotel`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `guestbook`
-- 

CREATE TABLE `guestbook` (
  `nama` varchar(20) NOT NULL,
  `email` varchar(15) NOT NULL,
  `pesan` varchar(100) NOT NULL,
  PRIMARY KEY  (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `guestbook`
-- 

INSERT INTO `guestbook` VALUES ('Muhammad Faisal', 'sad', 'asdasd');
INSERT INTO `guestbook` VALUES ('Salis Jauhar', 'sakuradewy@yaho', 'sdggd');
INSERT INTO `guestbook` VALUES ('Salis Jauhar', 'sakuhhradewy@ya', 'sdggd');
INSERT INTO `guestbook` VALUES ('sdas', 'qwqe', 'qewqwe');
INSERT INTO `guestbook` VALUES ('Indriani', 'asasfdsfdgfh', 'mnkjdskfksdjf');

-- --------------------------------------------------------

-- 
-- Table structure for table `petugas`
-- 

CREATE TABLE `petugas` (
  `id_petugas` varchar(6) NOT NULL,
  `nama_pet` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `bagian` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `petugas`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_bank`
-- 

CREATE TABLE `tbl_bank` (
  `id_bank` int(5) NOT NULL,
  `nama` varchar(10) NOT NULL,
  `no_reg` varchar(15) NOT NULL,
  PRIMARY KEY  (`id_bank`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_bank`
-- 

INSERT INTO `tbl_bank` VALUES (1, 'BRI', '824358340850230');
INSERT INTO `tbl_bank` VALUES (2, 'BNI', '097875564535456');
INSERT INTO `tbl_bank` VALUES (3, 'Mandiri', '65787980890876');
INSERT INTO `tbl_bank` VALUES (4, 'Jatim', '346362945256978');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_booking`
-- 

CREATE TABLE `tbl_booking` (
  `id_book` int(5) NOT NULL auto_increment,
  `nama_lengkap` varchar(30) NOT NULL,
  `id_kamar` int(5) NOT NULL,
  `jumlah` varchar(2) NOT NULL,
  `chek_in` date NOT NULL,
  `alamat` text NOT NULL,
  `chek_out` date NOT NULL,
  `id_bank` int(5) NOT NULL,
  PRIMARY KEY  (`id_book`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `tbl_booking`
-- 

INSERT INTO `tbl_booking` VALUES (15, 'Indriani', 45332, '2', '2013-05-31', 'dsdugfyu', '2013-05-09', 3);
INSERT INTO `tbl_booking` VALUES (14, 'Indriani', 45332, '1', '2013-05-01', 'erewt;rlg;dsk;lgljda;dkgdfsgdfkh', '2013-05-03', 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_kamar`
-- 

CREATE TABLE `tbl_kamar` (
  `id_kamar` int(5) NOT NULL,
  `tipe_kamar` varchar(15) NOT NULL,
  `harga` varchar(10) NOT NULL,
  `jumlah` varchar(5) NOT NULL,
  `sisa` varchar(5) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY  (`id_kamar`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_kamar`
-- 

INSERT INTO `tbl_kamar` VALUES (76355, 'VIP', '750000', '10', '10', 'Kosong');
INSERT INTO `tbl_kamar` VALUES (34536, 'Bisnis', '350000', '10', '10', 'Kosong');
INSERT INTO `tbl_kamar` VALUES (45332, 'Economic', '1750000', '15', '15', 'Kosong');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_tamu`
-- 

CREATE TABLE `tbl_tamu` (
  `id_tamu` varchar(6) NOT NULL,
  `id_book` varchar(6) NOT NULL,
  PRIMARY KEY  (`id_tamu`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_tamu`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_transaksi`
-- 

CREATE TABLE `tbl_transaksi` (
  `id_trk` varchar(6) NOT NULL,
  `id_book` varchar(6) NOT NULL,
  `id_kamar` varchar(6) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  PRIMARY KEY  (`id_trk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `tbl_transaksi`
-- 

